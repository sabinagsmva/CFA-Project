document.addEventListener('DOMContentLoaded', function() {
    const faqItems = document.querySelectorAll('.faq-item');

    faqItems.forEach(item => {
        const question = item.querySelector('.faq-question');
        const answer = item.querySelector('.faq-answer');
        const toggle = item.querySelector('.faq-toggle');

        question.addEventListener('click', () => {
            const isVisible = answer.classList.contains('show');
            
            
            document.querySelectorAll('.faq-answer').forEach(ans => {
                ans.classList.remove('show');
                ans.style.maxHeight = null;
                ans.style.padding = '0 15px';
            });

    
            document.querySelectorAll('.faq-toggle').forEach(tog => {
                tog.textContent = '+';
            });


            if (!isVisible) {
                answer.classList.add('show');
                answer.style.maxHeight = answer.scrollHeight + 'px';
                answer.style.padding = '10px 15px';
                toggle.textContent = '-';
            } else {
                toggle.textContent = '+';
            }
        });
    });
});
